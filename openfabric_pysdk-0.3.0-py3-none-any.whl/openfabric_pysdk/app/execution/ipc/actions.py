
class DispatchActions:
    ADD = 'add'
    CHECK = 'check'
    CONFIGURE = 'configure'
    EXIT = 'exit'
    FETCH = 'fetch'
    LOG = 'log'
    REMOVE = 'remove'
    APP_STATE = 'app_state'
    UPDATE = 'update'
    SCHEMA_UPDATE = 'schema_update'
    SYNC = 'sync'
